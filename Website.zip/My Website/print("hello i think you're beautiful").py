print("hello i think you're beautiful")
